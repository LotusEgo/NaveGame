-----Alteração fácil
Aumentar fonte de Pontos na tela de jogo                                                     FOI*********
Adicionar texto que Mostra tecla de pausa                                                    FOI*********
Criar condição de vitória                                                                    FOI*********



-----Alteração ok
Abrir aba de opções quando o jogo estiver pausado
Criar ciclo de animação para inimigos
Adicionar tipos de inimigo diferentes com alcances de velocidade menores
Fazer player e projeteis emitir luz, que interage com inimigos
Criar estrelas que aparecem e desaparecem em intervalos aleatórios e emitem luz
Trocar inimigos e o player para usarem imagens
Implementar leaderboard que salva os 10 maiores scores e possibilita colocar nome de até 5 caracteres
Player para de atirar quando troca direções
Definir limite de spawn de inimigos
Efeito quando ocorre colisão de inimigo com projetil ou com player
Implementar método de alteração de controles
Música para menu, jogo e derrota, pausar quando jogo pausar
Adicionar imagem para menu principal, derrota, vitória, options e crédito
Implementar slider para modificar volume da música
Adicionar limite para movimentação da nave para não sair da tela


-----Alteração talvez quebre o código
Alterar jogo para 3D
Só deixar uma janela de jogo aberta de cada vez




Drive: https://drive.google.com/drive/folders/18iVXbVgi8wtmBDGYGZFkgmE5YG7G9Cvi

O jogo deverá contemplar:
o Uso de Iluminação
o Coloração com realismo (usar tabela de cores) FOI******
o Interação com o usuário (teclado e/ou mouse) FOI*********
o Uso de animação
o Aplicação de textura